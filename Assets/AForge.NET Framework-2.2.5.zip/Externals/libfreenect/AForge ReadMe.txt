Libraries in this folder are part of the OpenKinect project and were built from its sources:
http://openkinect.org/
Sources from git's master branch was used. Last updated and built on February 20, 2012.

The libraries were built using VS.NET 2010. Configuration done with CMake.

See installation/build notes here:
http://openkinect.org/wiki/Getting_Started#Windows

